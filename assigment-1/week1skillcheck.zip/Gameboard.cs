using System;
using System.Collections.Generic;
using System.Text;

namespace assignment1 {
    class Gameboard {
        private char[,] board = new char[10, 10]; 
        private bool hacks;

        public Gameboard(bool hacks) {
            this.hacks = hacks;
            ResetBoard();
        }

        // Displays the gameboard on the screen with rows as cap letters and
        // cols as numbers
        public void Display() {
            Console.WriteLine("  1  2  3  4  5  6  7  8  9 10 ");

            for(int row = 0; row < board.GetLength(0); row++) {
                Console.Write($"{(char)(row+65)}");

                for(int col = 0; col < board.GetLength(0); col++) {
                    char position = board[row, col];
                    // hide ships if hacks are not enabled
                    if (position == 'S' && !hacks) {
                        position = '~';
                    }

                    Console.Write($"[{position}]");
                }

                Console.WriteLine();
            }
        }

        // Sets every board position to contain newChar
        public void FillBoard(char newChar) {
            for(int row = 0; row < board.GetLength(0); row++) {
                for(int col = 0; col < board.GetLength(0); col++) {
                    board[row,col] = newChar;
                }
            }
        }

        // resets the board with all water
        public void ResetBoard() {
            FillBoard('~');
        }

        // returns character at specified location
        public char GetCell(char row, int col) {
            int rowNumber = (int)(row-65);
            if (rowNumber > board.GetLength(0) || rowNumber < 0 || col < 0 || col > board.GetLength(1)) {
                return '@';
            }

            return board[rowNumber,col-1];
        }

        // sets board location to desired cell
        public bool SetCell(char row, int col, char newChar) {
            int rowNumber = (int)(row-65);
            if (rowNumber > board.GetLength(0) || rowNumber < 0 || col < 0 || col > board.GetLength(1)) {
                return false;
            }

            board[rowNumber,col-1] = newChar;
            return true;
        }

        // wrapper for GetLength(0); makes code outside this file more readable
        // and less confusing
        public int GetRowLength() {
            return board.GetLength(0);
        }

        // wrapper for GetLength(1); makes code outside this file more readable
        // and less confusing
        public int GetColLength() {
            return board.GetLength(1);
        }

    } 
}
