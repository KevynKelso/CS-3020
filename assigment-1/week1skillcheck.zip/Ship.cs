using System;

namespace assignment1 {
    class Ship {
        private int length;
        // if not vertical, it will be horizontal orientation
        private bool verticalOrientation;
        // can bowX bowY be calculated in gameboard, do we really need coord info?
        //private int bowX;
        //private int bowY;
        //private int sternX;
        //private int sternY;

        public Ship(int length, bool verticalOrientation, int bowX, int bowY, int sternX, int sternY) {
            if (length < 2 || length > 5) {
                Console.WriteLine($"Length {length} is invalid. Must be between 2 and 5");
            }
            this.length = length;
            this.verticalOrientation = verticalOrientation;
            //this.bowX = bowX;
            //this.bowY = bowY;
            //this.sternX = sternX; 
            //this.sternY = sternY;
        }
    }
}
