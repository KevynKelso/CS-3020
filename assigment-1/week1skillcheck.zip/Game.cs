using System;
using System.Text.RegularExpressions;

namespace assignment1 {
    class Game {
        private bool isRunning;
        private Gameboard board = new Gameboard(true);

        public Game() {
            this.isRunning = true;
        }

        // entry point into the game
        public void Start() {
            board.ResetBoard();
            board.Display();
            PlayerTurn();
        }

        // I might get rid of this method and put the loop in Start()
        public void Update() {
            while (isRunning) {
                board.Display();
                Console.ReadLine();
            }
        }

        // gets coord info from user
        private string PromptUser() {
            Console.Write("\nPlease enter target coordinates (row then col no spaces)");
            return Regex.Replace(Console.ReadLine().ToUpper().Trim(), @"\s+", "");
        }

        // ensures user input is within the parameters of the gameboard
        private bool valid(string input) {
            if (input.Length < 2 || input.Length > 3 || 
                (int)(input[0]-65) < 0 || (int)(input[0]-65) > board.GetRowLength() || 
                int.Parse(input.Substring(1)) < 0 || int.Parse(input.Substring(1)) > board.GetColLength()) {
                return false;
            }
            return true;
        }

        // basic player logic
        private void PlayerTurn() {
            char targetRow;
            int targetCol;

            string userInput = PromptUser();
            if (!valid(userInput)) {
                Console.WriteLine($"The input you entered: {userInput} is invalid. Please try again.");
                return;
            }
            
            targetRow = userInput[0];
            targetCol = int.Parse(userInput.Substring(1));
            Console.WriteLine($"Targeted Cell: {targetRow},{targetCol}\n");

            board.SetCell(targetRow, targetCol, 'x');
            board.Display();
        }


    }
}
