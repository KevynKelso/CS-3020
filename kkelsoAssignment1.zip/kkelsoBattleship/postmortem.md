# Postmotem

## Trials and Tribulations
For the most part, this project was pretty easy. I had some trouble writing everything
in one file Game.cs, then wasted time moving stuff to Ship.cs because I did too much
ship stuff in the Game.cs file. If I could go back, I'd spend more time in preproduction
outlining all the functionality of each class and what goes in what class. I'd also
focus more on the task at hand instead of trying to implement features that were
not neccessary.

## Time estimate
- preproduction: 0h 0m
- production: 8h
- *Total* 8 hours
